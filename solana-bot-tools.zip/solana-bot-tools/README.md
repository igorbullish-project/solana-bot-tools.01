# Solana Copytrading Tools (Devnet bundle)

This is a ready-to-run devnet bundle (backend + frontend) for the Solana copytrading starter.

## Quickstart (local)

1. Backend
```
cd backend
npm install
cp .env .env.local
# edit .env.local if needed (OPERATOR_WALLET set to your pubkey)
node server.js
```

2. Frontend
```
cd frontend
npm install
npm start
# open web or scan QR with Expo Go (phone)
```

## Notes
- OPERATOR_WALLET is set to: FLHsdYUaqBAUcbbFogqumkXyN3y4Ff2jhHXwXjxQZPVL
- The included `delegate.json` is a placeholder dev keypair **not** matching your pubkey. To use your own signing key, replace `delegate.json` with your secret key array (do NOT share private keys).
- This bundle is for **Devnet testing only**.
