import fs from 'fs';
import { Transaction, SystemProgram, Keypair, PublicKey, Connection } from '@solana/web3.js';
import dotenv from 'dotenv';
dotenv.config();

const RPC_URL = process.env.PRIVATE_RPC_URL || 'https://api.devnet.solana.com';
const connection = new Connection(RPC_URL, { commitment: 'processed' });

function loadDelegate() {
  const p = process.env.DELEGATE_KEY_PATH;
  if (!p) throw new Error('DELEGATE_KEY_PATH not set');
  const raw = JSON.parse(fs.readFileSync(p,'utf8'));
  return Keypair.fromSecretKey(Uint8Array.from(raw));
}

let delegate;
export function getDelegate() { if (!delegate) delegate = loadDelegate(); return delegate; }

export async function buildSignedTxBuffer(instr) {
  const del = getDelegate();
  const to = new PublicKey(instr.to);
  const lamports = Number(instr.lamports || 0);
  if (!lamports || lamports <= 0) throw new Error('Invalid lamports');

  const tx = new Transaction();
  tx.add(SystemProgram.transfer({ fromPubkey: del.publicKey, toPubkey: to, lamports }));
  const { blockhash } = await connection.getLatestBlockhash('processed');
  tx.recentBlockhash = blockhash;
  tx.feePayer = del.publicKey;
  tx.sign(del);
  return tx.serialize();
}
