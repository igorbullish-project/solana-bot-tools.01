import fs from "fs";
import fetch from "node-fetch";
import { Connection, Transaction, SystemProgram, Keypair, PublicKey } from "@solana/web3.js";
import dotenv from "dotenv";
dotenv.config();

const RPC_URL = process.env.PRIVATE_RPC_URL || "https://api.devnet.solana.com";
const COMMITMENT = "processed";
let connection;
function getConnection() {
  if (!connection) connection = new Connection(RPC_URL, { commitment: COMMITMENT, disableRetryOnRateLimit: true });
  return connection;
}

function loadDelegateKeypair() {
  const p = process.env.DELEGATE_KEY_PATH;
  if (!p) throw new Error("DELEGATE_KEY_PATH not set");
  const raw = JSON.parse(fs.readFileSync(p, "utf8"));
  return Keypair.fromSecretKey(Uint8Array.from(raw));
}

let delegateInstance;
function getDelegate() {
  if (!delegateInstance) delegateInstance = loadDelegateKeypair();
  return delegateInstance;
}

export async function fastExecuteSignal(instr) {
  if (!instr?.to) throw new Error("Invalid instruction: missing 'to'");
  const conn = getConnection();
  const delegate = getDelegate();

  const toPub = new PublicKey(instr.to);
  const lamports = Number(instr.lamports || 0);

  if (!lamports || lamports <= 0) throw new Error("Invalid lamports amount");

  const tx = new Transaction();
  tx.add(SystemProgram.transfer({ fromPubkey: delegate.publicKey, toPubkey: toPub, lamports }));

  const { blockhash } = await conn.getLatestBlockhash(COMMITMENT);
  tx.recentBlockhash = blockhash;
  tx.feePayer = delegate.publicKey;

  tx.sign(delegate);
  const raw = tx.serialize();

  if (process.env.MEV_RELAY_URL) {
    try {
      const resp = await fetch(process.env.MEV_RELAY_URL, { method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: raw });
      if (!resp.ok) throw new Error("MEV relay rejected tx");
      const text = await resp.text();
      console.log("MEV relay accepted: ", text);
      return text;
    } catch (err) {
      console.warn("MEV relay failed, falling back to direct RPC: ", err);
    }
  }

  const sig = await conn.sendRawTransaction(raw, { skipPreflight: true, maxRetries: 1 });
  console.log("fastExec sent tx: ", sig);
  return sig;
}
