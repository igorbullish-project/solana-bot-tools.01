import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";

dotenv.config();

import { fastExecuteSignal } from "./fastExec.js";
import { analyzeToken } from "./analyzer.js";
import { initGrpcClient, submitViaRelay } from "./grpcExec.js";
import { buildSignedTxBuffer } from "./txBuilder.js";

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

let clients = [];
let signals = [];

const SIGNALS_FILE = path.join(process.cwd(), "signals.json");
if (fs.existsSync(SIGNALS_FILE)) {
  try { signals = JSON.parse(fs.readFileSync(SIGNALS_FILE, "utf8")); } catch (e) { signals = []; }
}

// SSE endpoint
app.get("/stream", (req, res) => {
  res.set({ "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
  res.flushHeaders();
  clients.push(res);
  req.on("close", () => { clients = clients.filter((c) => c !== res); });
});

// initialize gRPC if configured
try { initGrpcClient(); } catch(e) { console.warn("gRPC init failed", e); }

// Post signal (protected by API key if ENABLE_API_KEY=true)
app.post("/signals", async (req, res) => {
  try {
    if (process.env.ENABLE_API_KEY === "true") {
      const key = req.header("x-api-key");
      if (!key || key !== process.env.MASTER_API_KEY) return res.status(401).json({ error: "Unauthorized" });
    }

    const { label, instructions, fastExecute } = req.body;
    if (!label || !Array.isArray(instructions)) return res.status(400).json({ error: "Invalid signal format" });

    const signal = { id: `sig-${Date.now()}`, label, instructions, createdAt: Date.now() };
    signals.unshift(signal);
    fs.writeFileSync(SIGNALS_FILE, JSON.stringify(signals, null, 2));

    // Broadcast via SSE
    for (const client of clients) client.write(`data: ${JSON.stringify(signal)}\n\n`);

    // Fast execute optionally (fire-and-forget)
    if (fastExecute === true) {
      for (const instr of instructions) {
        try {
          // attempt to build signed raw buffer and submit via relay first
          const raw = await buildSignedTxBuffer(instr);
          const relayRes = await submitViaRelay(raw);
          if (!relayRes) {
            // fallback to fastExec
            fastExecuteSignal(instr).catch((err) => console.error("fastExec failed:", err));
          }
        } catch (err) {
          console.error("fast-execute build/send error", err);
        }
      }
    }

    res.json({ success: true, signal });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err) });
  }
});

app.get("/signals", (req, res) => res.json(signals));

// Token analyzer endpoint
app.get("/analyze/:mint", async (req, res) => {
  try {
    const result = await analyzeToken(req.params.mint);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err) });
  }
});

app.listen(PORT, () => console.log(`✅ Signal server listening on ${PORT}`));
