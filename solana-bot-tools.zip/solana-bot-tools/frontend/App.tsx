import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, Button, ScrollView, TextInput } from 'react-native';

const SIGNAL_SERVER = 'http://localhost:4000';

export default function App() {
  const [signals, setSignals] = useState([]);
  const [status, setStatus] = useState('');
  const [mint, setMint] = useState('');
  const [analysis, setAnalysis] = useState(null);

  useEffect(() => {
    const es = new EventSource(`${SIGNAL_SERVER}/stream`);
    es.onmessage = (e) => {
      const s = JSON.parse(e.data);
      setSignals(prev => [s, ...prev]);
      setStatus(`New signal: ${s.label}`);
    };
    es.onerror = (err) => setStatus('Stream error');
    return () => es.close();
  }, []);

  async function analyze() {
    if (!mint) return alert('Isi mint address');
    setStatus('Analyzing...');
    const r = await fetch(`${SIGNAL_SERVER}/analyze/${mint}`);
    const j = await r.json();
    setAnalysis(j);
    setStatus('Analysis complete');
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{padding:20}}>
      <Text style={styles.title}>Solana Copytrading Tools (Devnet)</Text>
      <Text style={styles.status}>{status}</Text>

      <View style={{marginTop:20}}>
        <Text style={styles.h2}>Signals</Text>
        {signals.map(s => (
          <View key={s.id} style={styles.signal}>
            <Text>{s.label}</Text>
            <Text style={{fontSize:12,color:'#666'}}>created: {new Date(s.createdAt).toLocaleString()}</Text>
          </View>
        ))}
      </View>

      <View style={{marginTop:30}}>
        <Text style={styles.h2}>Analyze Token</Text>
        <TextInput style={styles.input} placeholder='Mint address' value={mint} onChangeText={setMint} />
        <Button title='Analyze' onPress={analyze} />
        {analysis && (
          <View style={{marginTop:10}}>
            <Text>Risk Score: {analysis.riskScore}</Text>
            <Text>Cached: {String(analysis.cached)}</Text>
            <Text>HolderCount: {analysis.holderCount}</Text>
          </View>
        )}
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor:'#fff', flex:1 },
  title: { fontSize:20, fontWeight:'bold' },
  status: { marginTop:8, color:'#333' },
  h2: { fontSize:16, fontWeight:'600' },
  signal: { padding:10, marginTop:8, backgroundColor:'#f2f2f2', borderRadius:8 },
  input: { borderWidth:1, borderColor:'#ccc', padding:8, marginTop:8, borderRadius:6 }
});
