import { Connection, PublicKey } from "@solana/web3.js";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";

dotenv.config();

const RPC_URL = process.env.PRIVATE_RPC_URL || "https://api.devnet.solana.com";
const connection = new Connection(RPC_URL, { commitment: "confirmed" });

const CACHE_PATH = path.join(process.cwd(), "analyzer_cache.json");
const CACHE_TTL_MS = Number(process.env.CACHE_TTL_MS || 600000);

function loadCache() {
  try { if (!fs.existsSync(CACHE_PATH)) return {}; return JSON.parse(fs.readFileSync(CACHE_PATH, "utf8")); } catch (e) { return {}; }
}
function saveCache(c) { try { fs.writeFileSync(CACHE_PATH, JSON.stringify(c, null, 2)); } catch (e) { console.error(e); } }
let cache = loadCache();

export async function analyzeToken(mintAddress) {
  const mint = new PublicKey(mintAddress);
  const now = Date.now();
  if (cache[mintAddress] && now - cache[mintAddress].timestamp < CACHE_TTL_MS) return { ...cache[mintAddress], cached: true };

  const result = { mint: mintAddress, timestamp: now };
  try { const supplyResp = await connection.getTokenSupply(mint); result.totalSupply = supplyResp.value.uiAmountString || String(supplyResp.value.amount); } catch (e) { result.error = [String(e)]; }
  try { const largest = await connection.getTokenLargestAccounts(mint); result.topHolders = largest.value.map(v => ({ address: v.address, amount: v.uiAmount || v.amount })); const total = largest.value.reduce((acc, v) => acc + Number(v.uiAmount ?? v.amount), 0) || 0; const top1 = Number(largest.value[0]?.uiAmount ?? largest.value[0]?.amount ?? 0); const top5 = largest.value.slice(0,5).reduce((acc,v)=>acc+Number(v.uiAmount ?? v.amount),0); result.top1_share = total>0?top1/total:null; result.top5_share = total>0?top5/total:null; } catch (e) { result.error = (result.error||[]).concat(String(e)); }
  try { const TOKEN_PROGRAM_ID = new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"); const filters = [{ dataSize: 165 }, { memcmp: { offset: 0, bytes: mint.toBase58() } }]; const accounts = await connection.getProgramAccounts(TOKEN_PROGRAM_ID, { filters, commitment: "confirmed" }); result.holderCount = accounts.length; } catch (e) { result.error = (result.error||[]).concat(String(e)); }
  try { const sampleAddrs = (result.topHolders||[]).slice(0,5).map(t=>new PublicKey(t.address)); const recent=[]; for(const addr of sampleAddrs){ const sigs = await connection.getSignaturesForAddress(addr,{limit:10}); recent.push({ address: addr.toBase58(), signatures: sigs.map(s=>s.signature) }); } result.recentActivity = recent; } catch(e){ result.error = (result.error||[]).concat(String(e)); }
  try { let score=100; if(result.top1_share!=null && result.top1_share>0.5) score-=40; if(result.top5_share!=null && result.top5_share>0.8) score-=30; if(result.holderCount!=null && result.holderCount<50) score-=30; result.riskScore=Math.max(0,Math.min(100,score)); } catch(e){}

  cache[mintAddress] = result; saveCache(cache);
  return { ...result, cached: false };
}

if (process.argv[1] && process.argv[1].endsWith("analyzer.js")) {
  (async ()=>{ const mint = process.argv[2]; if(!mint) return console.error("Usage: node analyzer.js <MINT_ADDRESS>"); const out = await analyzeToken(mint); console.log(JSON.stringify(out,null,2)); process.exit(0); })();
}
