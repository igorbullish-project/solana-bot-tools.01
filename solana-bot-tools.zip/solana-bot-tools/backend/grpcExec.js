import fs from 'fs';
import grpc from '@grpc/grpc-js';
import protoLoader from '@grpc/proto-loader';
import dotenv from 'dotenv';
import fetch from 'node-fetch';
dotenv.config();

const GRPC_ENDPOINT = process.env.GRPC_ENDPOINT;
const PROTO_PATH = process.env.PROTO_PATH;
const RELAY_URL = process.env.MEV_RELAY_URL;

let grpcClient = null;

export function initGrpcClient() {
  if (!GRPC_ENDPOINT || !PROTO_PATH) {
    console.log('gRPC not configured (GRPC_ENDPOINT or PROTO_PATH missing)');
    return null;
  }
  const packageDefinition = protoLoader.loadSync(PROTO_PATH, { keepCase: true, longs: String, enums: String, defaults: true, oneofs: true });
  const proto = grpc.loadPackageDefinition(packageDefinition);

  const service = proto.yellowstone?.GeyserService || proto.geyser?.GeyserService || proto.GeyserService || proto;
  if (!service) {
    console.warn('gRPC service not found in proto — inspect your provider proto file');
    return null;
  }

  grpcClient = new service(GRPC_ENDPOINT, grpc.credentials.createSsl());

  try {
    const call = grpcClient.SubscribeAccountUpdates?.({}) || grpcClient.Subscribe?.({}) || grpcClient.StreamAccounts?.({});
    if (call) {
      call.on('data', (msg) => { try { console.log('gRPC msg', JSON.stringify(msg).slice(0,800)); } catch(e){} });
      call.on('error', (err) => console.warn('gRPC stream error', err));
      call.on('end', () => console.log('gRPC stream ended'));
    } else {
      console.log('gRPC client created but no matching stream method found — adjust method name');
    }
  } catch (err) {
    console.warn('Failed to open gRPC stream (method mismatch?):', err);
  }

  return grpcClient;
}

export async function submitViaRelay(rawBuffer) {
  if (!RELAY_URL) {
    console.warn('No MEV_RELAY_URL configured — submitViaRelay returns null (caller should fallback).');
    return null;
  }
  try {
    const resp = await fetch(RELAY_URL, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: rawBuffer });
    if (!resp.ok) throw new Error(`Relay rejected: ${resp.status} ${await resp.text()}`);
    const text = await resp.text();
    console.log('Relay accepted:', text);
    return text;
  } catch (err) {
    console.warn('Relay submit failed:', err);
    return null;
  }
}
